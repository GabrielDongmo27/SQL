
PROMPT 
PROMPT specify password for DS as parameter 1:
DEFINE pass     = ds
PROMPT 
PROMPT specify default tablespeace for DS as parameter 2:
DEFINE tbs      = users
PROMPT 
PROMPT specify temporary tablespace for DS as parameter 3:
DEFINE ttbs     = temp
PROMPT 
PROMPT specify password for SYS as parameter 4:
DEFINE pass_sys = root
PROMPT 
PROMPT specify log path as parameter 5:
DEFINE log_path = C:\Users\DHG\Desktop\DELIVERY
PROMPT
PROMPT specify connect string as parameter 6:
DEFINE connect_string     = //localhost:1521/XEPDB1
PROMPT

CREATE OR REPLACE USER ds IDENTIFIED BY &pass;

GRANT CREATE SESSION, CREATE VIEW, ALTER SESSION, CREATE SEQUENCE TO ds;

CONNECT ds/&pass@&connect_string
ALTER SESSION SET NLS_LANGUAGE=French;
ALTER SESSION SET NLS_TERRITORY=France;