
PROMPT
PROMPT 
PROMPT ************ ADD AN ARTICLE TO A PACKAGE ************
PROMPT
PROMPT

PROMPT 
PROMPT Enter the package number:
DEFINE id_package     = &1
PROMPT

PROMPT 
PROMPT Enter the article id:
DEFINE id_article     = &2
PROMPT

PROMPT 
PROMPT Enter the quantity for the selected article:
DEFINE quantity     = &3
PROMPT

INSERT INTO PACKAGE_ARTICLE(ID_PACKAGE, ID_ARTICLE, QUANTITY)
VALUES(&id_package, &id_article, &quantity);

COMMIT;

PROMPT 
PROMPT ************ COMMANDE ENREGISTREE! ************
PROMPT

SELECT ID_PACKAGE, ID_ARTICLE, QUANTITY
FROM PACKAGE_ARTICLE
ORDER BY ID_PACKAGE;