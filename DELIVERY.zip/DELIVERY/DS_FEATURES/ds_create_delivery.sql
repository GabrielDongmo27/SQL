
PROMPT
PROMPT
PROMPT 
PROMPT ************ SCHEDULE A DELIVERY ************
PROMPT
PROMPT

PROMPT 
PROMPT Enter the assigned user"'"s identifier:
DEFINE id_user     = &1
PROMPT

PROMPT 
PROMPT Enter the date of the delivery:
DEFINE delivery_date     = &2
PROMPT

PROMPT
PROMPT 
PROMPT ************ ORDERS LIST ************
PROMPT
PROMPT

