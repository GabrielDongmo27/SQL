
PROMPT
PROMPT        
PROMPT ******** CREATION OF INSERTIONS FOR TABLES ********
PROMPT        
PROMPT

Prompt ******  Populating CITY table ....

INSERT INTO CITY VALUES 
        ( 1
        , 'DOUALA' 
        ); 

INSERT INTO CITY VALUES 
        ( 2
        , 'YAOUNDE' 
        );

INSERT INTO CITY VALUES 
        ( 3
        , 'BAFOUSSAM' 
        );

INSERT INTO CITY VALUES 
        ( 4
        , 'NGAOUNDERE' 
        );
INSERT INTO CITY VALUES 
        ( 5
        , 'EDEA' 
        );

-- 

Prompt ******  Populating ZONE table ....

INSERT INTO ZONE VALUES 
        ( 1
        , 3
        , 'Paachi'
        );
INSERT INTO ZONE VALUES 
        ( 2
        , 5
        , 'Eglise-Baptiste' 
        );
INSERT INTO ZONE VALUES 
        ( 3
        , 2
        , 'Mvog-Ada' 
        );
INSERT INTO ZONE VALUES 
        ( 4
        , 1
        , 'Akwa' 
        );
INSERT INTO ZONE VALUES 
        ( 5
        , 4
        , 'Carrefour-Amadou'
        );
INSERT INTO ZONE VALUES 
        ( 6
        , 3
        , 'Ndop'
        );
INSERT INTO ZONE VALUES 
        ( 7
        , 3
        , 'Lycée de Bafoussam'
        ); 
INSERT INTO ZONE VALUES 
        ( 8
        , 3
        , 'Ecole-Dochi'
        );
INSERT INTO ZONE VALUES 
        ( 9
        , 3
        , 'Tchinda'
        );
INSERT INTO ZONE VALUES 
        ( 10
        , 5
        , 'Poissonerie-Congelcam' 
        );
INSERT INTO ZONE VALUES 
        ( 11
        , 5
        , 'Carrefour de la citée' 
        );
INSERT INTO ZONE VALUES 
        ( 12
        , 5
        , 'Lycée Edea' 
        );
INSERT INTO ZONE VALUES 
        ( 13
        , 5
        , 'Immeuble Sonkeng' 
        ); 
INSERT INTO ZONE VALUES 
        ( 14
        , 2
        , 'Poste Centrale' 
        ); 
INSERT INTO ZONE VALUES 
        ( 15
        , 2
        , 'Mvan' 
        ); 
INSERT INTO ZONE VALUES 
        ( 16
        , 2
        , 'Elig-Essono' 
        ); 
INSERT INTO ZONE VALUES 
        ( 17
        , 2
        , 'Ekounou' 
        );  
INSERT INTO ZONE VALUES 
        ( 18
        , 1
        , 'Bonamoussadi' 
        ); 
INSERT INTO ZONE VALUES 
        ( 19
        , 1
        , 'Ndokoti' 
        ); 
INSERT INTO ZONE VALUES 
        ( 20
        , 1
        , 'Akwa-Nord' 
        ); 
INSERT INTO ZONE VALUES 
        ( 21
        , 1
        , 'Bonaberi' 
        ); 
INSERT INTO ZONE VALUES 
        ( 22
        , 4
        , 'Adjah-Zone'
        );
INSERT INTO ZONE VALUES 
        ( 23
        , 4
        , 'Imam-MustaphaII'
        );
INSERT INTO ZONE VALUES 
        ( 24
        , 4
        , 'Mosquée-Isaac'
        );  
INSERT INTO ZONE VALUES 
        ( 25
        , 4
        , 'Zone des moutons'
        );

-- 

Prompt ******  Populating ADDRESS table ....

INSERT INTO ADDRESS VALUES 
        ( 7824 
        , 'RUE BELFORT CITY'
        , 4
        );
INSERT INTO ADDRESS VALUES 
        ( 6842
        , 'RUE DE RIVOLI'
        , 2
        );
INSERT INTO ADDRESS VALUES 
        ( 2652 
        , 'RUE de la braise'
        , 5
        );
INSERT INTO ADDRESS VALUES 
        ( 3252
        , 'RUE Fotso-Victor'
        , 1
        );
INSERT INTO ADDRESS VALUES 
        ( 9835
        , 'RUE Hamadou-Hahidjo'
        , 3
        );
INSERT INTO ADDRESS VALUES 
        ( 7345
        , 'Rue de roi SOKOUDJOU '
        , 6
        );
INSERT INTO ADDRESS VALUES 
        ( 2475
        , 'Rue des Cultivateurs'
        , 9
        );
INSERT INTO ADDRESS VALUES 
        ( 1025
        , 'Rue du bonheur Ouest '
        , 7
        );
INSERT INTO ADDRESS VALUES 
        ( 8320
        , 'Rue autochtones Edea '
        , 10
        );
INSERT INTO ADDRESS VALUES 
        ( 5142
        , 'Rue des sauveteurs'
        , 8
        );
INSERT INTO ADDRESS VALUES 
        ( 3021
        , 'Rue des Impots'
        , 11
        );
INSERT INTO ADDRESS VALUES 
        ( 7414
        , 'Rue agences de transports'
        , 12
        );
INSERT INTO ADDRESS VALUES 
        ( 9874
        , 'Rue de la joie '
        , 13
        );
INSERT INTO ADDRESS VALUES 
        ( 2031
        , 'Rue Ekang '
        , 14
        );
INSERT INTO ADDRESS VALUES 
        ( 1254
        , 'Rue Syndicat transport '
        , 15
        );
INSERT INTO ADDRESS VALUES 
        ( 3214
        , 'Rue Ministre des finances '
        , 16
        );

INSERT INTO ADDRESS VALUES 
        ( 1010
        , 'Rue des Fonctionnaires '
        , 17
        );

INSERT INTO ADDRESS VALUES 
        ( 6521
        , 'Carrefour trois morts '
        , 18
        );

INSERT INTO ADDRESS VALUES 
        ( 5555
        , 'Rue des marthyrs '
        , 19
        );

INSERT INTO ADDRESS VALUES 
        ( 6005
        , 'Rue de la joie '
        , 20
        );

INSERT INTO ADDRESS VALUES 
        ( 7100
        , 'Rue Douala Manga Bell'
        , 21
        );

INSERT INTO ADDRESS VALUES 
        ( 2998
        , 'Rue du Jeun-Ramadan'
        , 22
        );

INSERT INTO ADDRESS VALUES 
        ( 1005
        , 'RUE des mosquées'
        , 23
        );

INSERT INTO ADDRESS VALUES 
        ( 4985
        , 'Rue du Grand-Nord'
        , 24
        );

INSERT INTO ADDRESS VALUES 
        ( 3001
        , 'Rue des Eleveurs'
        , 25
        );

-- 

Prompt ******  Populating WAREHOUSE table ....

INSERT INTO WAREHOUSE VALUES 
        ( 1
        , 4985
        , 'Rue du Grand-Nord'
        );
INSERT INTO WAREHOUSE VALUES 
        ( 2
        , 7100
        , 'Rue Douala Manga Bell'
        );
INSERT INTO WAREHOUSE VALUES 
        ( 3
        , 7824
        , 'RUE BELFORT CITY'
        );
INSERT INTO WAREHOUSE VALUES 
        ( 4
        , 9874
        , 'Rue de la joie ' 
        );
INSERT INTO WAREHOUSE VALUES 
        ( 5
        , 8320
        , 'Rue autochtones Edea '
        );

-- 

Prompt ******  Populating Type_Locomotive table ....

INSERT INTO Type_Locomotive VALUES 
        ( 1
        , 'Car' 
        );

INSERT INTO Type_Locomotive VALUES 
        ( 2
        , 'Truck' 
        );

INSERT INTO Type_Locomotive VALUES 
        ( 3
        , 'Informal' 
        );

INSERT INTO Type_Locomotive VALUES 
        ( 4
        , 'Motorcycle' 
        );

INSERT INTO Type_Locomotive VALUES 
        ( 5
        , 'Bike' 
        );

-- 

Prompt ****** Populating LOCOMOTIVE table ....

INSERT INTO LOCOMOTIVE VALUES 
        ( 1
        , 1
        , 50
        );

INSERT INTO LOCOMOTIVE VALUES 
        ( 2
        , 2
        , 500
        );

INSERT INTO LOCOMOTIVE VALUES 
        ( 3
        , 3
        , 150
        );

INSERT INTO LOCOMOTIVE VALUES 
        ( 4
        , 4
        , 2
        );

INSERT INTO LOCOMOTIVE VALUES 
        ( 5
        , 5
        , 2
        );

-- 

Prompt ******  Populating EMPLOYEES table ....

INSERT INTO EMPLOYEES VALUES
        (
          5
          ,698006133
          ,'Biondi'
          ,'Alban'
          ,'12/02/18'
       );

INSERT INTO EMPLOYEES VALUES
        ( 1
          ,677997562
          ,'Fisher'
          ,'Calvin'
          ,'01/11/20'
        );

INSERT INTO EMPLOYEES VALUES
        (
         2
         ,698688014
         ,'Milane'
         ,'Vince'
         ,'08/03/21'
        );

INSERT INTO EMPLOYEES VALUES
        (
          3
          ,654652310
          ,'Avenida'
          ,'Moscou'
          ,'19/10/21'
        );

INSERT INTO EMPLOYEES VALUES
        (
         4
         ,660432100
         ,'Rio'
         ,'Berlin'
         ,'12/03/21'
        );

INSERT INTO EMPLOYEES VALUES
        (
         6
         ,653859279
         ,'Gabriel'
         ,'Dongmo'
         ,'27/05/16'
        );

INSERT INTO EMPLOYEES VALUES
        (
         7
         ,667845908
         ,'Laurent'
         ,'Dongmo'
         ,'24/12/16'
        );

INSERT INTO EMPLOYEES VALUES
        (
         8
         ,699894834
         ,'Jervezine'
         ,'Naugning'
         ,'02/05/18'
        );

INSERT INTO EMPLOYEES VALUES
        (
         9
         ,676129645
         ,'Paul'
         ,'Camille'
         ,'19/09/13'
        );

INSERT INTO EMPLOYEES VALUES
        (
         10
         ,677548415
         ,'Chretien'
         ,'Toudjui'
         ,'19/09/13'
        );

-- 

Prompt ******  Populating USERS table ....

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_EMPLOYEE) VALUES 
        ( 1 
        , 8320
        , 'Rue autochtones Edea '
        , 3
        , 
        , 1
        );

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_EMPLOYEE) VALUES 
        ( 2 
        , 4985
        , 'Rue du Grand-Nord'
        , 2
        , 
        , 3
        );

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_LOCOMOTIVE, ID_EMPLOYEE) VALUES 
        ( 3 
        , 9874
        , 'Rue de la joie '
        , 2
        , 3
        , 2
        );

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_EMPLOYEE) VALUES 
        ( 4 
        ,  7824
        , 'RUE BELFORT CITY'
        , 5
        , 
        , 7
        );

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_LOCOMOTIVE, ID_EMPLOYEE) VALUES 
        ( 5 
        , 7100
        , 'Rue Douala Manga Bell'
        , 5
        , 2
        , 9
        );

-- 

REM ***************************insert data into the DELIVERY table

Prompt ******  Populating DELIVERY table ....

INSERT INTO DELIVERY VALUES 
        ( 1
        , 4
        , 3
        , 2
        , 52000
        , '12h:20min:00s'
        , '08/03/22'
        );

INSERT INTO DELIVERY VALUES 
        ( 2
        , 2
        , 5
        , 4
        , 8000
        ,'15h:00min:00s'
        ,'23/12/22'       
        );

INSERT INTO DELIVERY VALUES 
        ( 3
        , 2
        , 5
        , 1
        , 60000
        , '07h:45min:00s'
        , '23/12/21'      
        );

INSERT INTO DELIVERY VALUES 
        ( 4
        , 3
        , 2
        , 3
        , 35000
        , '16h:20min:00s'
        , '19/12/21'     
        );

INSERT INTO DELIVERY VALUES 
        ( 5
        , 3
        , 2
        , 5
        , 20500
        , '17h:23min:02s'
        , '09/02/22'       
        );

INSERT INTO DELIVERY VALUES 
        ( 6
        , 4
        , 3
        , 2
        , 52000
        , '15h:00min:00s'
        , '08/03/22'
        );

INSERT INTO DELIVERY VALUES 
        ( 7
        , 2
        , 5
        , 4
        , 8000
        ,'15h:00min:00s'
        ,'26/12/22'       
        );

INSERT INTO DELIVERY VALUES 
        ( 8
        , 2
        , 5
        , 1
        , 60000
        , '07h:45min:00s'
        , '01/02/22'      
        );

INSERT INTO DELIVERY VALUES 
        ( 9
        , 3
        , 2
        , 3
        , 35000
        , '19h:20min:00s'
        , '19/12/21'     
        );

INSERT INTO DELIVERY VALUES 
        ( 10
        , 3
        , 2
        , 5
        , 20500
        , '20h:23min:02s'
        , '09/02/22'       
        );

--

Prompt ******  Populating PACKAGE table ....

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         1,
         5,
         1,
         5142,
         'Rue des sauveteurs'
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         2,
         10,
         1,
         5142,
         'Rue des sauveteurs'
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         3,
         4,
         2,
         2998
        , 'Rue du Jeun-Ramadan'
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         4,
         9,
         2,
         2998
        , 'Rue du Jeun-Ramadan'
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         5,
         3,
         5,
        1254
        , 'Rue Syndicat transport '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         6,
         8,
         5,
        1254
        , 'Rue Syndicat transport '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         7,
         2,
         3,
        6521
        , 'Carrefour trois morts '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         8,
         7,
         3,
        6521
        , 'Carrefour trois morts '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         9,
         1,
         4,
        1010
        , 'Rue des Fonctionnaires '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         10,
         6,
         4,
        1010
        , 'Rue des Fonctionnaires '
        );

--

/*REM ***************************insert data into the Edition_Type table

Prompt ******  Populating Edition_Type table ....

INSERT INTO EDITION_TYPE VALUES 
        ( 1
        , 'Cancel order'
        );

INSERT INTO EDITION_TYPE VALUES 
        ( 2
        , 'Confirm order'
        );

INSERT INTO EDITION_TYPE VALUES 
        ( 3
        , 'Modify order'
        );

INSERT INTO EDITION_TYPE VALUES 
        ( 4
        , 'Add article to order'
        );

-- 

Prompt ****** Populating EDITION table

INSERT INTO EDITION VALUES
        (
          1
          ,4
          ,2
        );
INSERT INTO EDITION VALUES
        (
          2
          ,3
          ,1
        );
INSERT INTO EDITION VALUES
        (
          4
          ,5
          ,5
        );
INSERT INTO EDITION VALUES
        (
          5
          ,2
          ,4
        );
INSERT INTO EDITION VALUES
        (
          3
          ,1
          ,3
        );*/

-- 

REM ***************************insert data into the DELIVERY_CLASS table

Prompt ******  Populating DELIVERY_CLASS table ....

INSERT INTO DELIVERY_CLASS VALUES 
        ( 1
        , 'Very Small'
        , 1
        );

INSERT INTO DELIVERY_CLASS VALUES 
        ( 2
        , 'Small'
        , 5
        );

INSERT INTO DELIVERY_CLASS VALUES 
        ( 3
        , 'Medium'
        , 10
        );

INSERT INTO DELIVERY_CLASS VALUES 
        ( 4
        , 'Large'
        , 25
        );

INSERT INTO DELIVERY_CLASS VALUES 
        ( 5
        , 'Very Large'
        , 50
        );

-- 

Prompt ******  Populating ORDERS table ....

INSERT INTO ORDERS VALUES 
        ( 1
        , 5142
        , 'Rue des sauveteurs'
        , 3
        , '20/02/22'
        , '16h:20min:00s'
        );
                                
INSERT INTO ORDERS VALUES 
        ( 2
        , 2998
        , 'Rue du Jeun-Ramadan'
        , 1     
        , '20/03/22'
        , '07h:30min:00s'
        );
                
INSERT INTO ORDERS VALUES 
        ( 3
        , 6521
        , 'Carrefour trois morts '
        , 5     
        , '11/03/22'
        , '18h:20min:00s'
        );

INSERT INTO ORDERS VALUES 
        ( 4
        , 1010
        , 'Rue des Fonctionnaires '
        , 3     
        , '09/02/22'
        , '14h:30min:00s'
        );
                
INSERT INTO ORDERS VALUES 
        ( 5
        , 1254
        , 'Rue Syndicat transport '
        , 4      
        , '25/12/21'
        , '10h:00min:00s'
        );

--

Prompt ****** Populating PACKAGE_USER table

INSERT INTO PACKAGE_USER VALUES
        (
         1,
         2,
        '16h:20min:00s',
        '19/12/21'       
        );

INSERT INTO PACKAGE_USER VALUES
        (
         2,
         4,
        '17h:23min:02s',
        '09/02/22'    
        );

INSERT INTO PACKAGE_USER VALUES
        (
         3,
         5,
        '15h:00min:00s',
        '19/02/22'      
        );

INSERT INTO PACKAGE_USER VALUES
        (
         4,
         1,
        '07h:45min:00s',
        '23/12/21'     
        );

INSERT INTO PACKAGE_USER VALUES
        (
         5,
         3,
        '12h:20min:00s',
        '08/03/22'      
        );

-- 

REM ********** insert data into the ARTICLE table

Prompt ******  Populating ARTICLE table ....

INSERT INTO ARTICLE VALUES 
        ( 1
        , 3
        , 'Chaussure'
        , 0.1
        , 45000
        );

INSERT INTO ARTICLE VALUES 
        ( 2
        , 3
        , 'Chemise'
        , 0.01
        , 10000
        );

INSERT INTO ARTICLE VALUES 
        ( 3
        , 2
        , 'Refrigerateur'
        , 100
        , 300000
        );

INSERT INTO ARTICLE VALUES 
        ( 4
        , 1
        , 'Telephone'
        , 1
        ,150000
        );

INSERT INTO ARTICLE VALUES 
        ( 5
        , 2
        , 'Vitres'
        , 35.5
        , 50000
        );

INSERT INTO ARTICLE VALUES 
        ( 6
        , 3
        , 'Vivres Frais'
        , 8.5
        , 25000
        );

INSERT INTO ARTICLE VALUES 
        ( 7
        , 1
        , 'Pates Alimentaires'
        , 0.5
        , 30000
        );

INSERT INTO ARTICLE VALUES 
        ( 8
        , 2
        , 'Produits Cosmetique'
        , 5
        , 12000
        );

INSERT INTO ARTICLE VALUES 
        ( 9
        , 3
        , 'Appareils Electronique'
        , 10
        , 68000
        );

INSERT INTO ARTICLE VALUES 
        ( 10
        , 3
        , 'Mixeur'
        , 3
        , 13000
        );

INSERT INTO ARTICLE VALUES 
        ( 11
        , 1
        , 'Costumes'
        , 0.1
        , 250000
        );

INSERT INTO ARTICLE VALUES 
        ( 12
        , 2
        , 'iPhone'
        , 1.5
        , 150000
        );

INSERT INTO ARTICLE VALUES 
        ( 13
        , 2
        , 'Montre'
        , 1.5
        , 24000
        );

INSERT INTO ARTICLE VALUES 
        ( 14
        , 1
        , 'Greffes'
        , 0.1
        , 18000
        );

INSERT INTO ARTICLE VALUES 
        ( 15
        , 3
        , 'Ordinateur Portable'
        , 2
        , 36000
        );

-- 
Prompt ****** Populating PACKAGE_ARTICLE table

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          1
         ,14
         ,50
        );

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          2
         ,3
         ,1
        );

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          3
         ,1
         ,15
        );

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          4
         ,11
         ,100
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          5
         ,4
         ,25
        );

-- 
Prompt ***** Populating ORDER_ARTICLE table

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          1
         ,1
         ,10
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          3
         ,2
         ,15
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          2
         ,5
         ,15
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          4
         ,3
         ,30
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          5
         ,4
         ,15
        );

PROMPT
PROMPT ********* END OF TABLES INSERTIONS *********
PROMPT

@C:\Users\DHG\Desktop\DELIVERY\DS_TABLES\ds_seq
 













