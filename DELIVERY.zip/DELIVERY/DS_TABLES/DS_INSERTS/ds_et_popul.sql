
PROMPT
Prompt ******  Populating Edition_Type table ....

INSERT INTO EDITION_TYPE VALUES 
        ( 1
        , 'Cancel order'
        );

INSERT INTO EDITION_TYPE VALUES 
        ( 2
        , 'Confirm order'
        );

INSERT INTO EDITION_TYPE VALUES 
        ( 3
        , 'Modify order'
        );

INSERT INTO EDITION_TYPE VALUES 
        ( 4
        , 'Add article to order'
        );

