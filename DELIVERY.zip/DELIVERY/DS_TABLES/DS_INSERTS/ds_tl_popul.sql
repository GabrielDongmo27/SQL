
PROMPT
Prompt ******  Populating Type_Locomotive table ....

INSERT INTO Type_Locomotive VALUES 
        ( 1
        , 'Car' 
        );

INSERT INTO Type_Locomotive VALUES 
        ( 2
        , 'Truck' 
        );

INSERT INTO Type_Locomotive VALUES 
        ( 3
        , 'Informal' 
        );

INSERT INTO Type_Locomotive VALUES 
        ( 4
        , 'Motorcycle' 
        );

INSERT INTO Type_Locomotive VALUES 
        ( 5
        , 'Bike' 
        );

