
PROMPT
Prompt ******  Populating USERS table ....

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_EMPLOYEE) VALUES 
        ( 1 
        , 8320
        , 'Rue autochtones Edea '
        , 3
        , 1
        );

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_EMPLOYEE) VALUES 
        ( 2 
        , 4985
        , 'Rue du Grand-Nord'
        , 2
        , 3
        );

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_LOCOMOTIVE, ID_EMPLOYEE) VALUES 
        ( 3 
        , 9874
        , 'Rue de la joie '
        , 2
        , 3
        , 2
        );

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_EMPLOYEE) VALUES 
        ( 4 
        ,  7824
        , 'RUE BELFORT CITY'
        , 5
        , 7
        );

INSERT INTO USERS(ID_USER, BP, STREET, ID_WAREHOUSE, ID_LOCOMOTIVE, ID_EMPLOYEE) VALUES 
        ( 5 
        , 7100
        , 'Rue Douala Manga Bell'
        , 5
        , 2
        , 9
        );

