
PROMPT
Prompt ****** Populating PACKAGE_ARTICLE table

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          1
         ,14
         ,50
        );

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          2
         ,3
         ,1
        );

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          3
         ,1
         ,15
        );

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          4
         ,11
         ,100
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          5
         ,4
         ,25
        );

-- 
Prompt ***** Populating ORDER_ARTICLE table

INSERT INTO PACKAGE_ARTICLE VALUES
        (
          1
         ,1
         ,10
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          3
         ,2
         ,15
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          2
         ,5
         ,15
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          4
         ,3
         ,30
        );
INSERT INTO PACKAGE_ARTICLE VALUES
        (
          5
         ,4
         ,15
        );

