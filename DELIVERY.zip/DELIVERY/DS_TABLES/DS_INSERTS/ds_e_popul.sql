
PROMPT
Prompt ****** Populating EDITION table

INSERT INTO EDITION VALUES
        (
          1
          ,4
          ,2
        );
INSERT INTO EDITION VALUES
        (
          2
          ,3
          ,1
        );
INSERT INTO EDITION VALUES
        (
          4
          ,5
          ,5
        );
INSERT INTO EDITION VALUES
        (
          5
          ,2
          ,4
        );
INSERT INTO EDITION VALUES
        (
          3
          ,1
          ,3
        );

