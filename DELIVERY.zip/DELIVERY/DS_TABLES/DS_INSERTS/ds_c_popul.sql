
PROMPT
Prompt ******  Populating CITY table ....

INSERT INTO CITY VALUES 
        ( 1
        , 'DOUALA' 
        ); 

INSERT INTO CITY VALUES 
        ( 2
        , 'YAOUNDE' 
        );

INSERT INTO CITY VALUES 
        ( 3
        , 'BAFOUSSAM' 
        );

INSERT INTO CITY VALUES 
        ( 4
        , 'NGAOUNDERE' 
        );
INSERT INTO CITY VALUES 
        ( 5
        , 'EDEA' 
        );





