
PROMPT
Prompt ****** Populating LOCOMOTIVE table ....

INSERT INTO LOCOMOTIVE VALUES 
        ( 1
        , 1
        , 50
        );

INSERT INTO LOCOMOTIVE VALUES 
        ( 2
        , 2
        , 500
        );

INSERT INTO LOCOMOTIVE VALUES 
        ( 3
        , 3
        , 150
        );

INSERT INTO LOCOMOTIVE VALUES 
        ( 4
        , 4
        , 2
        );

INSERT INTO LOCOMOTIVE VALUES 
        ( 5
        , 5
        , 2
        );

