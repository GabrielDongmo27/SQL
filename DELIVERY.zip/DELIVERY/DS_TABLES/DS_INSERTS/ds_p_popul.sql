
PROMPT
Prompt ******  Populating PACKAGE table ....

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         1,
         5,
         1,
         5142,
         'Rue des sauveteurs'
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         2,
         10,
         1,
         5142,
         'Rue des sauveteurs'
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         3,
         4,
         2,
         2998
        , 'Rue du Jeun-Ramadan'
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         4,
         9,
         2,
         2998
        , 'Rue du Jeun-Ramadan'
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         5,
         3,
         5,
        1254
        , 'Rue Syndicat transport '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         6,
         8,
         5,
        1254
        , 'Rue Syndicat transport '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         7,
         2,
         3,
        6521
        , 'Carrefour trois morts '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         8,
         7,
         3,
        6521
        , 'Carrefour trois morts '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         9,
         1,
         4,
        1010
        , 'Rue des Fonctionnaires '
        );

INSERT INTO PACKAGE(ID_PACKAGE, ID_DELIVERY, ID_ORDER, BP, STREET) VALUES
        (
         10,
         6,
         4,
        1010
        , 'Rue des Fonctionnaires '
        );

