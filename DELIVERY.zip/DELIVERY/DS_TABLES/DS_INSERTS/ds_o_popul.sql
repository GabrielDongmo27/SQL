
PROMPT
Prompt ******  Populating ORDERS table ....

INSERT INTO ORDERS VALUES 
        ( 1
        , 5142
        , 'Rue des sauveteurs'
        , 3
        , '20/02/22'
        , '16h:20min:00s'
        );
                                
INSERT INTO ORDERS VALUES 
        ( 2
        , 2998
        , 'Rue du Jeun-Ramadan'
        , 1     
        , '20/03/22'
        , '07h:30min:00s'
        );
                
INSERT INTO ORDERS VALUES 
        ( 3
        , 6521
        , 'Carrefour trois morts '
        , 5     
        , '11/03/22'
        , '18h:20min:00s'
        );

INSERT INTO ORDERS VALUES 
        ( 4
        , 1010
        , 'Rue des Fonctionnaires '
        , 3     
        , '09/02/22'
        , '14h:30min:00s'
        );
                
INSERT INTO ORDERS VALUES 
        ( 5
        , 1254
        , 'Rue Syndicat transport '
        , 4      
        , '25/12/21'
        , '10h:00min:00s'
        );

