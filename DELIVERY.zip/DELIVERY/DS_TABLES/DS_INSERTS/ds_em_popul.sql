
PROMPT
Prompt ******  Populating EMPLOYEES table ....

INSERT INTO EMPLOYEES VALUES
        (
          5
          ,698006133
          ,'Biondi'
          ,'Alban'
          ,'12/02/18'
       );

INSERT INTO EMPLOYEES VALUES
        ( 1
          ,677997562
          ,'Fisher'
          ,'Calvin'
          ,'01/11/20'
        );

INSERT INTO EMPLOYEES VALUES
        (
         2
         ,698688014
         ,'Milane'
         ,'Vince'
         ,'08/03/21'
        );

INSERT INTO EMPLOYEES VALUES
        (
          3
          ,654652310
          ,'Avenida'
          ,'Moscou'
          ,'19/10/21'
        );

INSERT INTO EMPLOYEES VALUES
        (
         4
         ,660432100
         ,'Rio'
         ,'Berlin'
         ,'12/03/21'
        );

INSERT INTO EMPLOYEES VALUES
        (
         6
         ,653859279
         ,'Gabriel'
         ,'Dongmo'
         ,'27/05/16'
        );

INSERT INTO EMPLOYEES VALUES
        (
         7
         ,667845908
         ,'Laurent'
         ,'Dongmo'
         ,'24/12/16'
        );

INSERT INTO EMPLOYEES VALUES
        (
         8
         ,699894834
         ,'Jervezine'
         ,'Naugning'
         ,'02/05/18'
        );

INSERT INTO EMPLOYEES VALUES
        (
         9
         ,676129645
         ,'Paul'
         ,'Camille'
         ,'19/09/13'
        );

INSERT INTO EMPLOYEES VALUES
        (
         10
         ,677548415
         ,'Chretien'
         ,'Toudjui'
         ,'19/09/13'
        );

