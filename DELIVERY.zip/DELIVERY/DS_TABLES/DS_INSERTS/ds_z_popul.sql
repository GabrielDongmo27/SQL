
PROMPT
Prompt ******  Populating ZONE table ....

INSERT INTO ZONE VALUES 
        ( 1
        , 3
        , 'Paachi'
        );
INSERT INTO ZONE VALUES 
        ( 2
        , 5
        , 'Eglise-Baptiste' 
        );
INSERT INTO ZONE VALUES 
        ( 3
        , 2
        , 'Mvog-Ada' 
        );
INSERT INTO ZONE VALUES 
        ( 4
        , 1
        , 'Akwa' 
        );
INSERT INTO ZONE VALUES 
        ( 5
        , 4
        , 'Carrefour-Amadou'
        );
INSERT INTO ZONE VALUES 
        ( 6
        , 3
        , 'Ndop'
        );
INSERT INTO ZONE VALUES 
        ( 7
        , 3
        , 'Lycée de Bafoussam'
        ); 
INSERT INTO ZONE VALUES 
        ( 8
        , 3
        , 'Ecole-Dochi'
        );
INSERT INTO ZONE VALUES 
        ( 9
        , 3
        , 'Tchinda'
        );
INSERT INTO ZONE VALUES 
        ( 10
        , 5
        , 'Poissonerie-Congelcam' 
        );
INSERT INTO ZONE VALUES 
        ( 11
        , 5
        , 'Carrefour de la citée' 
        );
INSERT INTO ZONE VALUES 
        ( 12
        , 5
        , 'Lycée Edea' 
        );
INSERT INTO ZONE VALUES 
        ( 13
        , 5
        , 'Immeuble Sonkeng' 
        ); 
INSERT INTO ZONE VALUES 
        ( 14
        , 2
        , 'Poste Centrale' 
        ); 
INSERT INTO ZONE VALUES 
        ( 15
        , 2
        , 'Mvan' 
        ); 
INSERT INTO ZONE VALUES 
        ( 16
        , 2
        , 'Elig-Essono' 
        ); 
INSERT INTO ZONE VALUES 
        ( 17
        , 2
        , 'Ekounou' 
        );  
INSERT INTO ZONE VALUES 
        ( 18
        , 1
        , 'Bonamoussadi' 
        ); 
INSERT INTO ZONE VALUES 
        ( 19
        , 1
        , 'Ndokoti' 
        ); 
INSERT INTO ZONE VALUES 
        ( 20
        , 1
        , 'Akwa-Nord' 
        ); 
INSERT INTO ZONE VALUES 
        ( 21
        , 1
        , 'Bonaberi' 
        ); 
INSERT INTO ZONE VALUES 
        ( 22
        , 4
        , 'Adjah-Zone'
        );
INSERT INTO ZONE VALUES 
        ( 23
        , 4
        , 'Imam-MustaphaII'
        );
INSERT INTO ZONE VALUES 
        ( 24
        , 4
        , 'Mosquée-Isaac'
        );  
INSERT INTO ZONE VALUES 
        ( 25
        , 4
        , 'Zone des moutons'
        );





