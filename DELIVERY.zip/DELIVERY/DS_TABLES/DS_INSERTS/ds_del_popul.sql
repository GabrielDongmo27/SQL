
PROMPT
Prompt ******  Populating DELIVERY table ....

INSERT INTO DELIVERY VALUES 
        ( 1
        , 4
        , 3
        , 2
        , 52000
        , '12h:20min:00s'
        , '08/03/22'
        );

INSERT INTO DELIVERY VALUES 
        ( 2
        , 2
        , 5
        , 4
        , 8000
        ,'15h:00min:00s'
        ,'23/12/22'       
        );

INSERT INTO DELIVERY VALUES 
        ( 3
        , 2
        , 5
        , 1
        , 60000
        , '07h:45min:00s'
        , '23/12/21'      
        );

INSERT INTO DELIVERY VALUES 
        ( 4
        , 3
        , 2
        , 3
        , 35000
        , '16h:20min:00s'
        , '19/12/21'     
        );

INSERT INTO DELIVERY VALUES 
        ( 5
        , 3
        , 2
        , 5
        , 20500
        , '17h:23min:02s'
        , '09/02/22'       
        );

INSERT INTO DELIVERY VALUES 
        ( 6
        , 4
        , 3
        , 2
        , 52000
        , '15h:00min:00s'
        , '08/03/22'
        );

INSERT INTO DELIVERY VALUES 
        ( 7
        , 2
        , 5
        , 4
        , 8000
        ,'15h:00min:00s'
        ,'26/12/22'       
        );

INSERT INTO DELIVERY VALUES 
        ( 8
        , 2
        , 5
        , 1
        , 60000
        , '07h:45min:00s'
        , '01/02/22'      
        );

INSERT INTO DELIVERY VALUES 
        ( 9
        , 3
        , 2
        , 3
        , 35000
        , '19h:20min:00s'
        , '19/12/21'     
        );

INSERT INTO DELIVERY VALUES 
        ( 10
        , 3
        , 2
        , 5
        , 20500
        , '20h:23min:02s'
        , '09/02/22'       
        );

