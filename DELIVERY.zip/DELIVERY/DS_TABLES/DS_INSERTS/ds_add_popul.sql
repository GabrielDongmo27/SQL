
PROMPT
Prompt ******  Populating ADDRESS table ....

INSERT INTO ADDRESS VALUES 
        ( 7824 
        , 'RUE BELFORT CITY'
        , 4
        );
INSERT INTO ADDRESS VALUES 
        ( 6842
        , 'RUE DE RIVOLI'
        , 2
        );
INSERT INTO ADDRESS VALUES 
        ( 2652 
        , 'RUE de la braise'
        , 5
        );
INSERT INTO ADDRESS VALUES 
        ( 3252
        , 'RUE Fotso-Victor'
        , 1
        );
INSERT INTO ADDRESS VALUES 
        ( 9835
        , 'RUE Hamadou-Hahidjo'
        , 3
        );
INSERT INTO ADDRESS VALUES 
        ( 7345
        , 'Rue de roi SOKOUDJOU '
        , 6
        );
INSERT INTO ADDRESS VALUES 
        ( 2475
        , 'Rue des Cultivateurs'
        , 9
        );
INSERT INTO ADDRESS VALUES 
        ( 1025
        , 'Rue du bonheur Ouest '
        , 7
        );
INSERT INTO ADDRESS VALUES 
        ( 8320
        , 'Rue autochtones Edea '
        , 10
        );
INSERT INTO ADDRESS VALUES 
        ( 5142
        , 'Rue des sauveteurs'
        , 8
        );
INSERT INTO ADDRESS VALUES 
        ( 3021
        , 'Rue des Impots'
        , 11
        );
INSERT INTO ADDRESS VALUES 
        ( 7414
        , 'Rue agences de transports'
        , 12
        );
INSERT INTO ADDRESS VALUES 
        ( 9874
        , 'Rue de la joie '
        , 13
        );
INSERT INTO ADDRESS VALUES 
        ( 2031
        , 'Rue Ekang '
        , 14
        );
INSERT INTO ADDRESS VALUES 
        ( 1254
        , 'Rue Syndicat transport '
        , 15
        );
INSERT INTO ADDRESS VALUES 
        ( 3214
        , 'Rue Ministre des finances '
        , 16
        );

INSERT INTO ADDRESS VALUES 
        ( 1010
        , 'Rue des Fonctionnaires '
        , 17
        );

INSERT INTO ADDRESS VALUES 
        ( 6521
        , 'Carrefour trois morts '
        , 18
        );

INSERT INTO ADDRESS VALUES 
        ( 5555
        , 'Rue des marthyrs '
        , 19
        );

INSERT INTO ADDRESS VALUES 
        ( 6005
        , 'Rue de la joie '
        , 20
        );

INSERT INTO ADDRESS VALUES 
        ( 7100
        , 'Rue Douala Manga Bell'
        , 21
        );

INSERT INTO ADDRESS VALUES 
        ( 2998
        , 'Rue du Jeun-Ramadan'
        , 22
        );

INSERT INTO ADDRESS VALUES 
        ( 1005
        , 'RUE des mosquées'
        , 23
        );

INSERT INTO ADDRESS VALUES 
        ( 4985
        , 'Rue du Grand-Nord'
        , 24
        );

INSERT INTO ADDRESS VALUES 
        ( 3001
        , 'Rue des Eleveurs'
        , 25
        );




