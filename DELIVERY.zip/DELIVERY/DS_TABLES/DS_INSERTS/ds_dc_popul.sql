
PROMPT
Prompt ******  Populating DELIVERY_CLASS table ....

INSERT INTO DELIVERY_CLASS VALUES 
        ( 1
        , 'Very Small'
        , 1
        );

INSERT INTO DELIVERY_CLASS VALUES 
        ( 2
        , 'Small'
        , 5
        );

INSERT INTO DELIVERY_CLASS VALUES 
        ( 3
        , 'Medium'
        , 10
        );

INSERT INTO DELIVERY_CLASS VALUES 
        ( 4
        , 'Large'
        , 25
        );

INSERT INTO DELIVERY_CLASS VALUES 
        ( 5
        , 'Very Large'
        , 50
        );

