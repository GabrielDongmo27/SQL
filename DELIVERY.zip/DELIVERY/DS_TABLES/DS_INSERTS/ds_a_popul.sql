
PROMPT
Prompt ******  Populating ARTICLE table ....

INSERT INTO ARTICLE VALUES 
        ( 1
        , 3
        , 'Chaussure'
        , 0.1
        , 45000
        );

INSERT INTO ARTICLE VALUES 
        ( 2
        , 3
        , 'Chemise'
        , 0.01
        , 10000
        );

INSERT INTO ARTICLE VALUES 
        ( 3
        , 2
        , 'Refrigerateur'
        , 100
        , 300000
        );

INSERT INTO ARTICLE VALUES 
        ( 4
        , 1
        , 'Telephone'
        , 1
        ,150000
        );

INSERT INTO ARTICLE VALUES 
        ( 5
        , 2
        , 'Vitres'
        , 35.5
        , 50000
        );

INSERT INTO ARTICLE VALUES 
        ( 6
        , 3
        , 'Vivres Frais'
        , 8.5
        , 25000
        );

INSERT INTO ARTICLE VALUES 
        ( 7
        , 1
        , 'Pates Alimentaires'
        , 0.5
        , 30000
        );

INSERT INTO ARTICLE VALUES 
        ( 8
        , 2
        , 'Produits Cosmetique'
        , 5
        , 12000
        );

INSERT INTO ARTICLE VALUES 
        ( 9
        , 3
        , 'Appareils Electronique'
        , 10
        , 68000
        );

INSERT INTO ARTICLE VALUES 
        ( 10
        , 3
        , 'Mixeur'
        , 3
        , 13000
        );

INSERT INTO ARTICLE VALUES 
        ( 11
        , 1
        , 'Costumes'
        , 0.1
        , 250000
        );

INSERT INTO ARTICLE VALUES 
        ( 12
        , 2
        , 'iPhone'
        , 1.5
        , 150000
        );

INSERT INTO ARTICLE VALUES 
        ( 13
        , 2
        , 'Montre'
        , 1.5
        , 24000
        );

INSERT INTO ARTICLE VALUES 
        ( 14
        , 1
        , 'Greffes'
        , 0.1
        , 18000
        );

INSERT INTO ARTICLE VALUES 
        ( 15
        , 3
        , 'Ordinateur Portable'
        , 2
        , 450000
        );

