
PROMPT
Prompt ****** Populating PACKAGE_USER table

INSERT INTO PACKAGE_USER VALUES
        (
         1,
         2,
        '16h:20min:00s',
        '19/12/21'       
        );

INSERT INTO PACKAGE_USER VALUES
        (
         2,
         4,
        '17h:23min:02s',
        '09/02/22'    
        );

INSERT INTO PACKAGE_USER VALUES
        (
         3,
         5,
        '15h:00min:00s',
        '19/02/22'      
        );

INSERT INTO PACKAGE_USER VALUES
        (
         4,
         1,
        '07h:45min:00s',
        '23/12/21'     
        );

INSERT INTO PACKAGE_USER VALUES
        (
         5,
         3,
        '12h:20min:00s',
        '08/03/22'      
        );

