
PROMPT
Prompt ******  Populating WAREHOUSE table ....

INSERT INTO WAREHOUSE VALUES 
        ( 1
        , 4985
        , 'Rue du Grand-Nord'
        );
INSERT INTO WAREHOUSE VALUES 
        ( 2
        , 7100
        , 'Rue Douala Manga Bell'
        );
INSERT INTO WAREHOUSE VALUES 
        ( 3
        , 7824
        , 'RUE BELFORT CITY'
        );
INSERT INTO WAREHOUSE VALUES 
        ( 4
        , 9874
        , 'Rue de la joie ' 
        );
INSERT INTO WAREHOUSE VALUES 
        ( 5
        , 8320
        , 'Rue autochtones Edea '
        );


